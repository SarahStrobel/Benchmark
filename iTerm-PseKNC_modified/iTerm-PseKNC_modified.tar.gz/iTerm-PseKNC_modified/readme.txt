Modified version of iTerm-PseKNC from (http://lin-group.cn/server/iTerm-PseKNC/iTerm-PseKNC.rar) to work with Linux

install LibSVM
svm-scale and svm-predict has to be in your path

example
python iTerm-PseKNC_modified.py input.csv /path-to-output/prefix /path-to-iTerm/
